// 服务器项目.cpp : 定义控制台应用程序的入口点。
//
#include <unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<malloc.h>
#include<string.h>
#define SERVER_PORT 10000 //服务器端口号
#define QUEUE 20 //保存客户端请求的队列容量
int main()
{
	int msock;//声明主套接字描述符变量
	int ssock;//声明从套接字描述符变量
	int ret, num;//用于接收函数的返回值
	char buf[1024];//保存help信息的变量
	char* buffer = "ok";//保存ok信息的变量
	double* i;//保存客户端发来的第一个数字
	i = (double*)malloc(sizeof(double));
	char* j;//保存客户端发来的运算符信息
	j = (char*)malloc(sizeof(char));
	double* k;//保存客户端发来的第二个数字
	k = (double*)malloc(sizeof(double));
	double result = 0;//保存计算结果
	struct sockaddr_in servaddr;//声明服务器套接字端点地址结构体变量
	struct sockaddr_in clientaddr;//声明客户端套接字端点地址结构体变量
	//**********************创建主套接字 第一个参数为协议族标识 第二个参数为服务类型******//
	msock = socket(AF_INET, SOCK_STREAM, 0);
	if (msock < 0) {//调用socket()函数出错
		printf("Create Socket Failed!\n");
		exit(-1);
	}
	memset(&servaddr, 0, sizeof(servaddr));
	//********************************给服务器端 主套接字 端点地址变量 赋值**************//
	servaddr.sin_family = AF_INET;//协议族字段赋值
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);//IP地址字段赋值
	servaddr.sin_port = htons(SERVER_PORT);//端口号字段赋值
	//*********************************bind()函数绑定服务器主套接字和端口地址************//
	ret = bind(msock, (struct sockaddr*)&servaddr, sizeof(servaddr));
	if (ret < 0) {//调用bind()函数出错
		printf("Server Bind Port:%d Failed!\n", SERVER_PORT);
		exit(-1);
	}
	/******************listen()函数设置等待队列和套接字为被动模式*************************/
	ret = listen(msock, QUEUE);
	if (ret < 0) {//调用listen()函数出错
		printf("Listen Failed!\n");
		exit(-1);
	}
	/***************************以下while(1)循环读取来自不同客户端的连接请求*************/
	while (1) {
		memset(&clientaddr, 0, sizeof(clientaddr));
		unsigned int len = sizeof(clientaddr);
		/***************accept()接受客户连接请求并创建套接字*****************************/
		ssock = accept(msock, (struct sockaddr*)&clientaddr, &len);
		if (ssock < 0) {//调用accept()函数出错
			printf("Accept Failed!\n");
			break;
		}
		/******************调用recev()/send()函数基于从套接字和客户交互******************/
		memset(buf, '\0', sizeof(buf));
		num = 0;
		num = recv(ssock, buf, sizeof(buf), 0);//接收客户发送的HELP消息
		if(num<0){
			printf("Recieve Data Failed!\n");
			break;
		}
		printf("%s\n", buf);
		num = 0;
		num = send(ssock, buffer, strlen(buffer), 0);
		if (num != strlen(buffer)) {
			printf("Send Data Failed!\n");
			break;
		}
		num = 0;
		num=recv(ssock,i,sizeof(double),0);//接收客户发来的第一个数字
			if (num<0) {
				printf("Recieve Data Failed!\n");
				break;
			}
		num = 0;
		num = recv(ssock, j, sizeof(char), 0);//接收客户发来的运算符
			if (num<0) {
				printf("Recieve Data Failed!\n");
				break;
			}
		num = 0;
		num = recv(ssock, k, sizeof(double), 0);//接收客户发来的第二个数字
			if (num<0) {
				printf("Recieve Data Failed!\n");
				break;
			}
		printf("接收到的客户端数据为：i=%f,j=%c,k=%f\n", *i, *j, *k);
		/***************************根据四则运算符计算出结果***********************/
		switch (*j) {
		case '+'://加法
			result = *i + *k;
			break;
		case '-'://减法
			result = *i - *j;
			break;
		case '*': 
			result = (*i)*(*j);
			break;
		default:
			result = (*i) / (*k);
			break;
		}
		num = 0;
		num = send(ssock, &result, sizeof(double), 0);//结果返回客户
		if (num < 0) {//调用send()函数出错
			printf("send data failed\n");
			break;
		}
		/*********************与客户交互完毕，关闭从套接字********************/
		close(ssock);

	}
	/*服务器端退出，将主套接字关闭*/
	close(msock);
	return 0;
}
