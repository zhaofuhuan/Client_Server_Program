#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<malloc.h>
#define SERVERIP "192.168.1.102"//定义ip地址常量
#define SERVERPORT 10000 //定义端口号常量
int main(){
    int ret ,num=0;
    int tsock;  //声明客户端套接字描述符变量
    double* i=0;    //声明保存第1个数字信息的变量
    i=(double*)malloc(sizeof(double));
    char* j;  //声明保存运算符的变量
    j=(char*)malloc(sizeof(char));
    double* k=0;    //声明保存第2个数字信息的变量
    k=(double*)malloc(sizeof(double));
    double result=0;    //声明保存计算结果的变量
    char* buffer="HELP";   //声明保存help信息的变量
    char buf[20];   //声明接收服务器应答消息的变量
    struct sockaddr_in servaddr;    //声明服务器套接字端点地址结构体变量
    /******************************创建客户端套接字**********************************************/
    tsock=socket(AF_INET,SOCK_STREAM,0);    
    if(tsock<0){    //调用套接字函数出错
        printf("Create Socket Failed!\n");
        exit(-1);
    }
    memset(&servaddr,0,sizeof(servaddr));
    /*****************************服务器套接字端点地址变量***************************/
    servaddr.sin_family=AF_INET;    //协议族字段
    servaddr.sin_port=htons(SERVERPORT);    //端口号字段
    inet_aton(SERVERIP,&servaddr.sin_addr);     //IP地址字段
    /*********************调用connect()函数向服务器发起TCP连接请求*****************/
    ret=connect(tsock,(struct sockaddr*)&servaddr,sizeof(struct sockaddr));
    if(ret<0){  //调用connect()函数失败
        printf("Connect Failed!\n");
        exit(-1);
    }
    /***************************利用send()函数和从套接字发送服务器数据***************/
    num=send(tsock,buffer,strlen(buffer),0);    //发送help信息给服务端
    if(num!=strlen(buffer))
    {
        printf("Send Data Failed!\n");
        exit(-1);
    }
    /***************************使用recv()函数从套接字读取服务器端发送过来的数据************/
    num=0;
    num=recv(tsock,buf,sizeof(buf),0);  //接收服务器的应答信息
    if(num<0){
        printf("Receive Data Failed!\n");
        exit(-1);
    }
    printf("%s\n",buf);
    *i=1.0;
    *j='+';
    *k=2.0;
    num=0;
    num=send(tsock,i,sizeof(double),0); //  发送第1个数字给服务器
    if(num<0){
        printf("Send Data Failed!\n");
        exit(-1);
    }
    num=0;
    num=send(tsock,j,sizeof(char),0);//发送运算符给服务器
    if(num<0){
        printf("Send Data Failed!\n");
        exit(-1);
    }
     num=0;
    num=send(tsock,k,sizeof(double),0); //  发送第1个数字给服务器
    if(num<0){
        printf("Send Data Failed!\n");
        exit(-1);
    }
    num=0;
    num=recv(tsock,&result,sizeof(double),0);   //从服务器接收计算结果
    if(num<0){
        printf("Receive Data Failed!\n");
        exit(-1);
    }
    printf("result :%f\n",result);
    close(tsock);
    free(i);
    free(j);
    free(k);
    return 0;
}

